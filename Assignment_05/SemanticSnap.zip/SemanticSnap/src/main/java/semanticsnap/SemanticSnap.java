package semanticsnap;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

abstract class Target {
	public Point2D center;
	public Circle shape;

	public Target(double x, double y) {
		center = new Point2D(x, y);
		shape = new Circle(30);
		shape.setTranslateX(x);
		shape.setTranslateY(y);
	}
	
	abstract public Point2D snap(Circle cursor);
}

class AttractingTarget extends Target {
	public AttractingTarget(double x, double y) {
		super(x, y);
		shape.setFill(Color.CYAN);
	}

	@Override
	public Point2D snap(Circle cursor) {
		Point2D cursorCenter = new Point2D(cursor.getTranslateX(), cursor.getTranslateY());
		// (b) todo: implement
                return cursorCenter;
	}
}

class RepellingTarget extends Target {
	public RepellingTarget(double x, double y) {
		super(x, y);
		shape.setFill(Color.RED);
	}
	
	@Override
	public Point2D snap(Circle cursor) {
		Point2D cursorCenter = new Point2D(cursor.getTranslateX(), cursor.getTranslateY());              
		// (a) todo: implement
		return cursorCenter;
	}
}

public class SemanticSnap extends Application {

	Circle cursor = new Circle(20, Color.BLUE);
	Target[] targets = {
		new AttractingTarget(100, 100),
		new RepellingTarget(400, 100),
		new AttractingTarget(400, 400),
		new RepellingTarget(100, 400),
	};

	private Target closestTarget(Point2D p) {
		double dMin = Double.POSITIVE_INFINITY;
		Target result = targets[0];
		for (Target t : targets) {
			double d = p.distance(t.center);
			if (d < dMin) {
				dMin = d;
				result = t;
			}
		}
		return result;
	}

	@Override
	public void start(Stage stage) {
		Pane root = new Pane();
		for (Target t : targets) {
			root.getChildren().add(t.shape);
		}
		root.getChildren().add(cursor);

		root.addEventFilter(MouseEvent.MOUSE_MOVED, e -> {
			Point2D p = new Point2D(e.getSceneX(), e.getSceneY());
			cursor.setTranslateX(p.getX());
			cursor.setTranslateY(p.getY());
			Target t = closestTarget(p);
			Point2D q = t.snap(cursor);
			cursor.setTranslateX(q.getX());
			cursor.setTranslateY(q.getY());
		});

		Scene scene = new Scene(root, 500, 500);
		stage.setTitle("Attract-Repel");
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		launch(args);
	}

}
