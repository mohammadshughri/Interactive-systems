package luh.hci.lifting;

/**
 *
 * @author michaelrohs
 */
public interface Procedure1<A> {
    public void apply(A a);
}
