package lifting;

/**
 *
 * @author michaelrohs
 */
public interface Function1<A, R> {
    public R apply(A a);
}
