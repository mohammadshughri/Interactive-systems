package calculator;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.StringBinding;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import jdk.jfr.Event;
import lifting.EventStream;

import static lifting.Lifting.link;
import static lifting.Lifting.map;

/**
 *
 * @author michaelrohs
 */
public class Calculator extends Application {

    @Override
    public void start(Stage primaryStage) {
        TextField inputA = new TextField("1");
        TextField inputB = new TextField("2");
        Label outputC = new Label();

        VBox box = new VBox(10, inputA, inputB, outputC);
        box.setPadding(new Insets(10));

        /* @todo */

        StackPane root = new StackPane();
        root.getChildren().add(box);

        Scene scene = new Scene(root, 200, 150);

        primaryStage.setTitle("Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
