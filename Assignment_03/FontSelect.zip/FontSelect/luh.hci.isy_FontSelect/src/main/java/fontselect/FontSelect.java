package fontselect;

/* Fonts:
 * http://docs.oracle.com/javase/8/javafx/api/javafx/scene/doc-files/cssref.html#typefont
 */


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class FontSelect extends Application {

	private String fontName = "Arial";
	private double fontSize = 24;
	private FontWeight fontWeight = FontWeight.NORMAL;
	private FontPosture fontPosture = FontPosture.REGULAR;
	private final GaussianBlur fontBlur = new GaussianBlur(0);
	private Color fontColor = Color.BLACK;

	@Override
	public void start(Stage stage) {

		//////////////////////////////////////////
		// structure
		
		TextField searchField = new TextField();

		ObservableList<String> familiesAll = FXCollections.observableList(Font.getFamilies());
		ListView<String> familiesListView = new ListView<>();
		FilteredList<String> families = familiesAll.filtered(item -> true);
		familiesListView.setItems(families);

		Label countView = new Label();

		ProgressBar percentageView = new ProgressBar(1);
		countView.setText(Integer.toString(families.size()));
		countView.setPrefWidth(50);
		HBox.setHgrow(percentageView, Priority.ALWAYS);
		percentageView.setMaxWidth(Double.MAX_VALUE);
		HBox remainingHBox = new HBox(5, countView, percentageView);
		remainingHBox.setPadding(new Insets(5));

		Text text = new Text();
		Font font = Font.font(fontName, fontWeight, fontPosture, fontSize);
		text.setFont(font);
		text.setWrappingWidth(600);
		text.setTextAlignment(TextAlignment.CENTER);
		text.setText("The quick brown fox jumps over the lazy dog");

		StackPane textPane = new StackPane(text);
		textPane.setPrefHeight(100);
		textPane.setMinHeight(100);

		Slider sizeSlider = new Slider(8, 48, fontSize);
		sizeSlider.setOrientation(Orientation.HORIZONTAL);
		HBox.setHgrow(sizeSlider, Priority.ALWAYS);
		sizeSlider.setMaxWidth(Double.MAX_VALUE);
		HBox sizeBox = new HBox(10, new Label("Size:"), sizeSlider);

		Slider blurSlider = new Slider(0, 10, fontBlur.getRadius());
		blurSlider.setOrientation(Orientation.HORIZONTAL);
		HBox.setHgrow(blurSlider, Priority.ALWAYS);
		blurSlider.setMaxWidth(Double.MAX_VALUE);
		HBox blurBox = new HBox(10, new Label("Blur:"), blurSlider);

		CheckBox underlineCheck = new CheckBox("Underline");

		CheckBox strikethroughCheck = new CheckBox("Strikethrough");

		ToggleGroup colorGroup = new ToggleGroup();
		RadioButton blackButton = new RadioButton("Black");
		blackButton.setUserData(Color.BLACK);
		blackButton.setToggleGroup(colorGroup);
		blackButton.setSelected(true);
		RadioButton redButton = new RadioButton("Red");
		redButton.setUserData(Color.RED);
		redButton.setToggleGroup(colorGroup);
		RadioButton blueButton = new RadioButton("Blue");
		blueButton.setUserData(Color.BLUE);
		blueButton.setToggleGroup(colorGroup);

		ToggleGroup weightGroup = new ToggleGroup();
		RadioButton normalButton = new RadioButton("Normal");
		normalButton.setUserData(FontWeight.NORMAL);
		normalButton.setToggleGroup(weightGroup);
		normalButton.setSelected(true);
		RadioButton boldButton = new RadioButton("Bold");
		boldButton.setUserData(FontWeight.BOLD);
		boldButton.setToggleGroup(weightGroup);

		ToggleGroup postureGroup = new ToggleGroup();
		RadioButton regularButton = new RadioButton("Regular");
		regularButton.setUserData(FontPosture.REGULAR);
		regularButton.setToggleGroup(postureGroup);
		regularButton.setSelected(true);
		RadioButton italicButton = new RadioButton("Italic");
		italicButton.setUserData(FontPosture.ITALIC);
		italicButton.setToggleGroup(postureGroup);

		VBox controlsBox = new VBox(10, sizeBox, blurBox, underlineCheck, strikethroughCheck,
				new Label("Color:"), blackButton, redButton, blueButton,
				new Label("Weight:"), normalButton, boldButton,
				new Label("Posture:"), regularButton, italicButton
		);
		controlsBox.setPadding(new Insets(10));
		controlsBox.setPrefWidth(300);

		VBox.setVgrow(familiesListView, Priority.ALWAYS);
		VBox fontNamesBox = new VBox(10, searchField, familiesListView, remainingHBox);

		HBox upperPane = new HBox(10, fontNamesBox, controlsBox);
		VBox root = new VBox(10, upperPane, textPane);

		Scene scene = new Scene(root, 700, 500);

		stage.setTitle("Font Select");
		stage.setScene(scene);
		stage.show();

		//////////////////////////////////////////
		// behavior

		// set font to focused list item
		
		// filter list as text is entered in search field
		// (ignore case, show all fonts whose name contains the search text)
		
		// update the countView to show the number of fonts remaining in the list
		
		// update the percentageView to show the percentage of fonts remaining)
		
		// update font size as sizeSlider is modified
		
		// update underline through checkbox
		
		// update strikethrough through checkbox
		
		// update font color with radio buttons
		
		// update font weight with radio buttons
		
		// update font posture with radio buttons
		
		// update font blurring as slider is modified

	}

	public static void main(String[] args) {
		launch(args);
	}

}
