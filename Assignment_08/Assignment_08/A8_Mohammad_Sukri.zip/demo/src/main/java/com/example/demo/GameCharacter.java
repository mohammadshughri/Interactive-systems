package com.example.demo;

public class GameCharacter {
    public void moveUp() {
        // Implement the logic to move the character up
    }

    public void moveDown() {
        // Implement the logic to move the character down
    }

    public void moveLeft() {
        // Implement the logic to move the character left
    }

    public void moveRight() {
        // Implement the logic to move the character right
    }
}

