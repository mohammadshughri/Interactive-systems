package eventsample;

public interface Procedure {
	void call();
}
